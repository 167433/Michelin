package pl.javaprojektpierwszy.movieLibary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieLibaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieLibaryApplication.class, args);
	}

}
