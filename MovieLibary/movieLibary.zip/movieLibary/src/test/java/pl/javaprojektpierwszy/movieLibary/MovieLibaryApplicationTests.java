package pl.javaprojektpierwszy.movieLibary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieLibaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
